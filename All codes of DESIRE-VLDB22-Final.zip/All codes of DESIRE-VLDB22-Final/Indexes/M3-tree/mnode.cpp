
#include "mnode.h"
Mnode::Mnode() {
	fadis = 0;
	radi = 0;
	son = 0;
	//len = 0;
	objloc = -1;
	metricnum = 0;
	data = NULL;
	radiarr = NULL;
	fadisarr = NULL;

}
void Mnode::copy(Mnode* m) {
	fadis = m->fadis;	
	objloc = m->objloc;
	//len = m->len;
	metricnum = m->metricnum;
	radi = 0;
	objloc = m->objloc;
	data = new Object(m->data);
	radiarr = new double[metricnum];
	fadisarr = new double[metricnum];	
	for (int i = 0; i < metricnum; i++)
	{
		fadisarr[i] = m->fadisarr[i];
		radiarr[i] = m->radiarr[i];
	}

}
double Mnode::distance(Mnode* m,int metric)
{
	if (m == NULL) {
		cout << "!!!!!!!! m is NULL" << endl;
		return 0;
	}
	return data->distance(m->data,metric);	
}
Mnode::Mnode(Object* o,int metricn) {	
	fadis = 0;	
	radi = 0;
	son = -1;
	objloc = 0;
	metricnum = metricn;
	radiarr = new double[metricnum];
	fadisarr = new double[metricnum];
	for (int i = 0; i < metricnum; i++)
	{
		fadisarr[i] = 0;
		radiarr[i] =0;
	}
	data = new Object(o);
}


Mnode::~Mnode() {
	delete data;
	delete[]fadisarr;
	delete[]radiarr;	
}

int Mnode::getsize()
{
	//return size * sizeof(double) + 2 * sizeof(int);
	
	int i = 0;
	i = 3 * sizeof(int)+(2+2*metricnum)*sizeof(double);
	if(objloc>-0.5)i += data->getsize();
	return i;
}


int Mnode::read_from_buffer(char* buffer)
{
	int i=0;	
		
	memcpy(&objloc, &buffer[i], sizeof(int));
	i += sizeof(int);

	memcpy(&son, &buffer[i], sizeof(int));
	i += sizeof(int);
	
	memcpy(&metricnum, &buffer[i], sizeof(int));
	i += sizeof(int);

	memcpy(&radi, &buffer[i], sizeof(double));
	i += sizeof(double);

	memcpy(&fadis, &buffer[i], sizeof(double));
	i += sizeof(double);

	radiarr = new double[metricnum];
	memcpy(radiarr, &buffer[i], metricnum * sizeof(double));
	i += metricnum * sizeof(double);

	fadisarr = new double[metricnum];
	memcpy(fadisarr, &buffer[i], metricnum * sizeof(double));
	i += metricnum * sizeof(double);
	if(objloc!=-1){
		delete data;
	data = new Object();
	i += data->read_from_buffer(&buffer[i]);
	}

	//cout << "Mnode total size " << i << endl;
	//cout << "Mnode tst " << getsize() << endl;
	return i;
}

int Mnode::write_to_buffer(char* buffer)
{
	int i=0;

	memcpy(&buffer[i], &objloc, sizeof(int));
	i += sizeof(int);

	memcpy(&buffer[i], &son, sizeof(int));
	i += sizeof(int);

	memcpy(&buffer[i], &metricnum, sizeof(int));
	i += sizeof(int);

	memcpy(&buffer[i], &radi, sizeof(double));
	i += sizeof(double);

	memcpy(&buffer[i], &fadis, sizeof(double));
	i += sizeof(double);

	memcpy(&buffer[i], radiarr, metricnum * sizeof(double));
	i += metricnum * sizeof(double);

	memcpy(&buffer[i], fadisarr, metricnum * sizeof(double));
	i += metricnum * sizeof(double);

	if(objloc!=-1)i += data->write_to_buffer(&buffer[i]);

	//outnode();
	//cout << "Mnode total size " << i<<endl;
	//cout << "Mnode tst " << getsize()<<endl;
	return i;
}

void Mnode::outnode(string str)
{		
	cout << str << "son " << son << " radi " << radi << " fadis " << fadis << " metricnum " << metricnum;	
	cout << " fadis ";
	for (int i = 0; i < metricnum; i++) cout << fadisarr[i] << " ";
	//cout << endl;
	cout << " radi ";
	for (int i = 0; i < metricnum; i++) cout << radiarr[i] << " ";
	cout << " ## ";
	if (objloc > 0) {
		Object* q = Obj_f->get_object(objloc);
		cout << "           " <<" id "<< q->id;
	}
	cout << "           " << " data obj " << objloc << " data:";
	if (data == NULL) {
		cout << "           " << " data impossible " << endl;
	}
	else data->outnode();	

	//cout << endl;
}
