#define _CRT_SECURE_NO_WARNINGS

#include <time.h>
#include <vector>
#include<algorithm>

#define eps 0.00000000001
#ifndef __leafmax
#define __leafmax


#endif


#include "./iopack/blk_file.h"
#include "./iopack/cache.h"
#include "./iopack/gadget.h"
#include "./iopack/RAF.h"

#include "object.h"
#include "mtree.h"
#include <queue>
using namespace std;
//int f=0;
double compdists;
double IOread = 0;
double IOwrite = 0;
int bolcksize;
RAF* Obj_f;
RAF* Index_f;
Cache* Obj_c;
Cache* Index_c;

double* querym;
int pmtree;
int n, m;
int* metricm;
double* metricmaxdis;
int st=0;

bool Obj_Comp(const AnsLeaf* a, const AnsLeaf* b) {
	if (a->obj < b->obj)    return true;
	return false;
}

bool Ans_Comp(const AnsLeaf* a, const AnsLeaf* b) {
	if (a->dis < b->dis)    return true;
	return false;
}


int main() {
	string filedata, querydata;
	ifstream in1;
	in1.open("data/par.txt");
	in1 >> filedata >> querydata;


//	freopen("ans.txt", "w", stdout);
	//srand((int)time(NULL));
	srand(0);
	int buffer_size = 1;
	bolcksize =8192;
	Obj_f = new RAF();
	Obj_f->init("M3Obj-Block", bolcksize, NULL);	
	Objectarr* record = new Objectarr();
	// cout << "come on 1" << endl;
	record->readfile(filedata);
	in1.close();
	//m = 3;
	st = 0;
	querym = new double[m];
	for (int i = 0; i < m; i++) querym[i] = 0;
	//for (int i =0; i < 2; i++) querym[i] = 1;
	//for (int i = 0; i < m; i++) cout <<"metric "<<i<<" "<< metricm[i] << endl;
	
	int* objloc = new int[n + 1 ];
	Obj_c = NULL;
	char* buffer = new char[Obj_f->file->blocklength];
	Obj_f->file->append_block(buffer);
	for (int i = 0; i < n; i++) {
		objloc[i] = Obj_f->add_object(record->arr[i]);
	}	
	//Obj_c = new Cache(buffer_size, bolcksize);
	//Obj_f->init_restore("Obj-Block", Obj_c);
	//Obj_c->clear();
	cout << "block end : "<< Obj_f->file->get_num_of_blocks() << endl;
	/*
	for (int i = max(n/50-2,0); i < n / 40; i++) {
		Object* q=Obj_f->get_object(objloc[i]);
		cout << objloc[i] << " is objlooc " << endl;
		q->outnode();
		delete q;
		}
	*/
	Index_f = new RAF();
	Index_f->init("M3Index-Block", bolcksize, NULL);
	cout << n << " " << m << endl;
	char* buf = new char[Index_f->file->get_blocklength()];
	Index_f->file->append_block(buf);
	//return 0;
	 {
		Mtree* p = new Mtree();	
		p->write_to_buffer(buf);
		pmtree = Index_f->file->append_block(buf);
		p->block=pmtree; 
		delete p;
	}
	 cout << "building beg" << endl;
	for (int i = 0; i < n; i++) {		
			Mnode* q = new Mnode(record->arr[i],m);	
			q->objloc = objloc[i];
			Mtree* p = new Mtree();			
			p->loadroot(pmtree);				
			p->insert(q);		
			delete p;		
	}
	//f = 0;
	double rad = 4;
	int knn = 5;
	int qpos = 4;
	int ost = max(n / 50 - 2, 0) + 1;
	cout << "building end" << endl;

	//=========== multi querytest ==========

	{
		in1.open(querydata);
		int quepos[200];
		int qcount;
		double quem = 0;
		for (int i = 0; i < m; i++) {
			in1 >> querym[i];
			quem += querym[i];
		}
		int quemk, quemr;
		double* radius;
		int* kvalues;

		in1 >> quemk;
		kvalues = new int[quemk];
		for (int i = 0; i < quemk; i++) in1 >> kvalues[i];

		in1 >> quemr;
		radius = new double[quemr];
		for (int i = 0; i < quemr; i++) in1 >> radius[i];

		in1 >> qcount;
		for (int i = 0; i < qcount; i++) {
			in1 >> quepos[i];
			quepos[i] %= n;
		}
		in1.close();
		clock_t begin, endt;
		begin = clock();
		ofstream ou1;
		ou1.open("ans-m3-8k.txt");

		for (int i = 0; i < quemk; i++) {
				compdists = 0;
				IOread = 0;
				begin = clock();
				for (int j = 0; j < qcount; j++) {
					Mtree* p = new Mtree();
					Mnode* que = new Mnode(record->arr[quepos[j]], m);
					vector<AnsLeaf*> tmpres = p->knnq(pmtree, que, kvalues[i], querym);
					for (int jj = 0; jj < tmpres.size(); jj++) {
						AnsLeaf* qq = tmpres[jj];
						tmpres[jj] = NULL;
						delete qq;
					}
					tmpres.clear();
					delete que;
					delete p;
				}
				endt = clock();
				ou1 << "knn=" << kvalues[i] << "\t" << (endt - begin) * 1.0 / CLOCKS_PER_SEC / qcount;
				ou1 << "\t" << compdists * 1.0 / qcount;
				ou1 << "\t" << IOread * 1.0 / qcount << endl;
			}
		for (int i = 0; i < quemr; i++) {
				compdists = 0;
				IOread = 0;
				int qsum = 0;
				begin = clock();
				for (int j = 0; j < qcount; j++) {
					Mtree* p = new Mtree();
					Mnode* que = new Mnode(record->arr[quepos[j]], m);
					vector<AnsLeaf*> tmpres = p->rangeq(pmtree, que, radius[i] * quem, 0, querym);
					qsum += tmpres.size();
					for (int jj = 0; jj < tmpres.size(); jj++) {
						AnsLeaf* qq = tmpres[jj];
						tmpres[jj] = NULL;
						delete qq;
					}
					tmpres.clear();
					delete que;
					delete p;
				}
				endt = clock();
				ou1 << "rnn=" << radius[i] << "\t" << (endt - begin) * 1.0 / CLOCKS_PER_SEC / qcount;
				ou1 << "\t" << compdists * 1.0 / qcount;
				ou1 << "\t" << IOread * 1.0 / qcount << endl;
				ou1 << "============ total "<< qsum *100.0/ qcount /n<<" Percentage ====== "<< qsum*1.0 / qcount << " Objects " << endl;
			}
		

		ou1.close();

	}
	return 0;



}

