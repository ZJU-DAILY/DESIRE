
#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <iostream>
#include <sstream>
#include <time.h>
#include <cmath>
#include "basemetric.h"
extern double compdists;
using namespace std;
double trans(double ddd1, double ddd2) {
	int dd1 = (int)ddd1;
	int dd2 = (int)ddd2;
	int y2, m2, d2;
	int y1, m1, d1;

	m1 = ((dd1 % 10000) / 100 + 9) % 12;
	y1 = dd1 / 10000 - m1 / 10;
	d1 = 365 * y1 + y1 / 4 - y1 / 100 + y1 / 400 + (m1 * 306 + 5) / 10 + (dd1 % 100 - 1);

	m2 = ((dd2 % 10000) / 100 + 9) % 12;
	y2 = (dd2 / 10000) - m2 / 10;
	d2 = 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 + (m2 * 306 + 5) / 10 + (dd2 % 100 - 1);

	return d1 - d2;
}
double trans2(double ddd1, double ddd2) {
	int dd1 = (int)ddd1;
	int dd2 = (int)ddd2;
	int y1 = dd1 / 10000, m1 = (dd1 / 100) % 100, d1 = dd1 % 100;
	int y2 = dd2 / 10000, m2 = (dd2 / 100) % 100, d2 = dd2 % 100;
	return ((y1 - y2) * 60 + m1 - m2) * 60 + d1 - d2;
}
