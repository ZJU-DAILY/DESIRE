#pragma once
#ifndef __mnode
#define __mnode

#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <iostream>
#include <sstream>
#include <time.h>
#include <cmath>
#include "object.h"
using namespace std;
extern RAF* Obj_f;

class Mnode
{
public:	
	string debug;
	//int metric;
	int metricnum;
	int objloc;
	//int len;
	int son;
	//char* datas;
	//double* datad;
	Object* data;
	double radi, fadis;
	double* radiarr;
	double* fadisarr;
	double dis;
	void outnode(string str);
	int getsize();
	int write_to_buffer(char* buffer);
	int read_from_buffer(char* buffer);
	Mnode();
	void copy(Mnode* m);
	double distance(Mnode* m,int metric);
	Mnode(Object* o,int metricn);	
	~Mnode();

};

#endif