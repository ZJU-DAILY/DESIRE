#ifndef __mtree
#define __mtree

#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <iostream>
#include <sstream>
#include <time.h>
#include <cmath>
#include "object.h"
#include "mnode.h"
#include "iopack/RAF.h"
#include "iopack\blk_file.h"

using namespace std;
extern int* metricm;


extern RAF* Obj_f;
extern RAF* Index_f;
extern Cache* Obj_c;
extern Cache* Index_c;


class AnsLeaf;
//extern int f ;
class Mtree
{
public:
	
	int block,dirty, fa, isleaf, leafnum;
	double radi;
	Mnode* routing;
	Mnode** son;
	void outnode(string str);
	int getsize();
	int write_to_buffer(char* buffer);
	int read_from_buffer(char* buffer);	
	void flush();

	Mtree();
	~Mtree();
	void loadroot(int page);
	void insert(Mnode* q);
	void entere(Mnode* q);
	void bfs(string str);
	void bfs1(string str);
	
	void split(int flag,Mtree* rtt);	

	vector<AnsLeaf*> rangeq(int root,Mnode* q, double r,int flag, double* querym);
	vector<AnsLeaf*> knnq(int root, Mnode* q, int knn, double* querym);
	void delnode(int loc);
	void updaterad(int loc, double* sradi);

};


class AnsLeaf
{
public:
	int metric;
	int obj;
	double dis;
	double radi;
	int loc;
	Object* o;
	Mtree* tree;
	AnsLeaf(int i, double k);
	~AnsLeaf();
};

#endif