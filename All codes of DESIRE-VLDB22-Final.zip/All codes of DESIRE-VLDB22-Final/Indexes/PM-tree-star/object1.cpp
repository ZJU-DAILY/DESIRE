#include "object.h"
#include <stdio.h>
#include <memory.h>
#include <cstring>
#include "iopack/RAF.h"
#include "iopack\blk_file.h"



extern RAF* Obj_f;
extern RAF* Index_f;
extern Cache* Obj_c;
extern Cache* Index_c;

#include <math.h>
#include <sstream>
#include <iostream>



Object::Object()
{
	datad = NULL;
	size = NULL;
	datas = NULL;
	ansres = NULL;
	
	istravel = 0;
	dist = 0;
}


void Object::ini(string str) {
	stringstream sstr1(str);
//	cout << "we " << str << endl;
	string s1;
	double d1;	
	sized = 0;
	sizes = 0;
	
	size = new int[m * 2];
//	cout << "m " << m << endl;
	for (int i = 0; i < m; i++) {	
		switch (metricm[i]) {
			case 0:
				sstr1 >> d1;
		//		cout << "0 " << d1 << endl;
				sized++;
				break;
			case 1:
				sstr1 >> s1;				
			//	cout << "1 " << s1 << endl;
				sized ++;
				for (int k = 0; s1[k]; k++) if (s1[k] == ',')sized++;									
				break;
			case 2:
				sstr1 >> s1;
			//	cout << "2 " << s1 << endl;
				sizes += s1.length();
				break;
		}
	}	
	datad = new double[sized];
	datas = new char[sizes];
	ansres = new double[m];
	//cout << "sized sizes " << sized << " " << sizes << endl;
	stringstream sstr2(str);
	sizes = 0;
	sized = 0;
	for (int j = 0; j < m; j++) {		
		switch (metricm[j]) {		
		case 0:			
			size[j * 2] = sized;
			sstr2 >> d1;
			datad[sized] = d1;
			sized++;
			size[j * 2+1] = sized;
			break;
		case 1:{
			size[j * 2] = sized;
			sstr2 >> s1;		
			sized++;
			for (int k = 0; s1[k]; k++)
				if (s1[k] == ',') {
					s1[k] = ' ';
					sized++;
				}
			size[j * 2+1] = sized;
			stringstream sstr3(s1);
			for (int i = size[j * 2]; i < size[j * 2 + 1]; i++) {
				sstr3 >> datad[i];
			}			
			break;
		}
		case 2:
			size[j * 2] = sizes;
			sstr2 >> s1;
			sizes += s1.length();
			size[j * 2+1] = sizes;
			for (int i = size[j * 2]; i < size[j * 2 + 1]; i++) {
				datas[i]=(char)s1[i- size[j * 2]];
			}
			break;
		}	
		
		ansres[j] = -1;
	}
}

void Object::outnode()
{
	cout << " id " << id;
	cout << " data :";
	for (int j = 0; j < m; j++) {
		switch (metricm[j]) {
		case 0:
		case 1:
			for (int i = size[j * 2]; i < size[j * 2 + 1]; i++) {
				cout<<datad[i]<<",";
			}
			cout << " # ";
			break;		
		case 2:
			for (int i = size[j * 2]; i < size[j * 2 + 1]; i++) {
				cout <<datas[i];
			}
			cout << " # ";
			break;
		}
	}
	cout << endl;
	/*
	cout<< " disres :";
	for (int i = 0; i < m; i++)
		cout << " " << ansres[i];
	cout << endl<<endl;
	*/
}

Objectarr::Objectarr()
{
	n = 0;
	m = 0;
}


Objectarr::~Objectarr()
{

	if (arr != NULL)
		delete[] arr;
}

void Objectarr::readfile()
{
	ifstream in1;
	ofstream ou1, ou2, ou3;
	n = 0;
	m = 10000;
	string str;
	in1.open("testmulti.txt");
	//getline(in1, str);
//	ou1.open("tmp.txt");
	in1 >> n >> m;
//	n = 20;
	metricm = new int[m];
	for (int i = 0; i < m; i++) in1 >> metricm[i];
	arr = new Object * [n + 1];
	cout << n << " " << m << endl;	
	getline(in1, str);
	for (int i = 0; i < n; i++) {
		getline(in1, str);
		//cout << "trying " << str << endl;
		arr[i] = new Object();
//		cout << "new finish " << str << endl;
		arr[i]->ini(str);
		arr[i]->id = i;
		//arr[i]->outnode();		
	}


	cout << "readm" << endl;
	ou1.close();
}
/*
double Object::distance(Object* other, int  m)
{
	switch (metricm[m]) {
	case 0:
		case 1:{
			double* a1 = new double[size[m * 2 + 1] - size[m * 2]];
			double* a2 = new double[size[m * 2 + 1] - size[m * 2]];

			for (int i = size[m * 2]; i < size[m * 2 + 1]; i++) {
				a1[i] = datad[i];
				a2[i] = other->datad[i];
			}
			return baseme( a1, a2, NULL, NULL, metricm[m], -size[m * 2]+ size[m * 2 + 1]);
			break; }
		case 2:{
			char* a1 = new char[size[m * 2 + 1] - size[m * 2]];
			char* a2 = new char[size[m * 2 + 1] - size[m * 2]];
			for (int i = size[m * 2]; i < size[m * 2 + 1]; i++) {
				a1[i] = datas[i];
				a2[i] = other->datas[i];
			}
			return baseme(NULL, NULL, a1, a2, metricm[m], -size[m * 2] + size[m * 2 + 1]);
			break;
			}
	}
	
	return 0;
	
	return dist;
}

*/


Object::Object(const Object* o)
{
	/*
	id = o->id;
	if (o->data != NULL)
	{
		data = new double[m];
		for (int i = 0; i < m; i++)
			data[i] = o->data[i];
	}
	else
		data = NULL;
	*/
}


Object::~Object()
{

	if (ansres != NULL)
		delete[]ansres;
	if (datad != NULL)
		delete[] datad;
	if (datas != NULL)
		delete[] datas;
	if (size != NULL)
		delete[] size;
	datad = NULL;
	ansres = NULL;
	datas = NULL;
	size = NULL;

}


int Object::getsize()
{
	//return size * sizeof(double) + 2 * sizeof(int);
	
	int i = 0;
	i+= sizeof(id);
	i += sizeof(sized);
	i += sizeof(sizes);
//	i += sizeof(dist);
//	i += sizeof(istravel);
	i += sized * sizeof(double);	
	i += sizes * sizeof(char);
//	i += m * sizeof(double);
	i += 2*m * sizeof(int);

	return i;
}


int Object::read_from_buffer(char* buffer)
{
	int i;
	memcpy(&id, buffer, sizeof(id));
	i = sizeof(id);

	memcpy(&sized, &buffer[i], sizeof(sized));
	i += sizeof(sized);

	memcpy(&sizes, &buffer[i], sizeof(sizes));
	i += sizeof(sizes);

//	ansres = new double[m];
//	memcpy(ansres, &buffer[i], m * sizeof(double));
//	i += m * sizeof(double);

	size = new int[2*m];
	memcpy(size, &buffer[i], 2*m * sizeof(int));
	i += m*2 * sizeof(int);

	datad = new double[sized];
	memcpy(datad, &buffer[i], sized * sizeof(double));
	i += sized * sizeof(double);
//	cout << "start i " << i << endl;

	datas = new char[sizes];
	memcpy(datas, &buffer[i], sizes * sizeof(char));
	i += sizes * sizeof(char);
//	cout << "end i " << i << endl;
	return i;
}

int Object::write_to_buffer(char* buffer)
{
	int i;

	memcpy(buffer, &id, sizeof(id));
	i = sizeof(id);

	memcpy(&buffer[i], &sized, sizeof(sized));
	i += sizeof(sized);

	memcpy(&buffer[i], &sizes, sizeof(sizes));
	i += sizeof(sizes);

//	memcpy(&buffer[i], ansres, m * sizeof(double));
//	i += m * sizeof(double);

	memcpy(&buffer[i], size, 2*m * sizeof(int));
	i += 2*m * sizeof(int);

	memcpy(&buffer[i], datad, sized * sizeof(double));
	i += sized * sizeof(double);
	
	memcpy(&buffer[i], datas, sizes * sizeof(char));	
	i += sizes * sizeof(char);

	return i;
}




















