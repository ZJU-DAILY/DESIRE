#pragma once
#ifndef __mnode
#define __mnode

#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <iostream>
#include <sstream>
#include <time.h>
#include <cmath>
#include "object.h"
using namespace std;
extern RAF* Obj_f;

class Mnode
{
public:	
	string debug;
	int metric;
	int objloc;
	int len;
	int son;
	char* datas;
	double* datad;
	double radi, fadis;
	double dis;
	void outnode(string str);
	int getsize();
	int write_to_buffer(char* buffer);
	int read_from_buffer(char* buffer);
	Mnode();
	void copy(Mnode* m);
	double distance(Mnode* m);
	Mnode(int m,Object* o);	
	~Mnode();

};

#endif