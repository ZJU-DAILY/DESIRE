#include "object.h"
#include "mtree.h"
#include <queue> 
AnsLeaf::AnsLeaf(int i,int j,double k) {
	metric = j;
	obj = i;
	dis = k;
	o = NULL;
}
AnsLeaf::~AnsLeaf() {
}

Mtree::Mtree() {
	dirty = 0;
	block = -1;
	fa = -1;
	//metric = -1;
	isleaf = 1;
	//type = -1;
	leafnum=0;
	son = NULL;
	routing = new Mnode();
}
Mtree::~Mtree() {
	if (f == 1) {
		//outnode("====== ");
	}
	if (dirty&&block>-1)	{
		//cout << "flushing" << endl;
		flush();
	}
	else if (dirty) {
		//cout << "this Mtree written failed" << endl;
	}
	else {
		//cout << "No need to write this Node" << endl;
	}
	//cout << "buffer finish" << endl;
	delete routing;
	//cout << "routing finish" << endl;
	//cout << leafnum << endl;
	for (int i = 0; i < leafnum; i++) {
	//	son[i]->outnode("");
		delete son[i];
		son[i] = NULL;
//		cout << "deleting "<<i << endl;
	}
	//cout << "deleting  node" << endl;
	if (son!=NULL) delete[] son;		
	//cout << "deleting  finish" << endl;
}
int Mtree::getsize()
{
	//return size * sizeof(double) + 2 * sizeof(int);
	int ii = 0;	
	ii = 3*sizeof(int);
	ii += routing->getsize();
	for (int i = 0; i < leafnum; i++) {
//		son[i]->outnode("getsize ");
		//if (son[i]->metric < 0) outnode("!!error Mtree ");
		ii += son[i]->getsize();
	}
	return ii;
}
int Mtree::read_from_buffer(char* buffer)
{
	int i;
	memcpy(&fa, buffer, sizeof(int));
	i = sizeof(int);


	memcpy(&isleaf, &buffer[i], sizeof(int));
	i += sizeof(int);


	memcpy(&leafnum, &buffer[i], sizeof(int));
	i += sizeof(int);
	
	int pos;
	delete routing;
	routing = new Mnode();
	pos = routing->read_from_buffer(&buffer[i]);
	i += pos;
	
	son = new Mnode * [leafnum];	
	for (int j = 0; j < leafnum; j++) {		
		son[j] = new Mnode();
		pos = son[j]->read_from_buffer(&buffer[i]);
		i += pos;			
	}
	return i;
}
int Mtree::write_to_buffer(char* buffer)
{

	int i;	

	memcpy(buffer, &fa, sizeof(int));
	i = sizeof(int);

	memcpy(&buffer[i], &isleaf, sizeof(int));
	i += sizeof(int);
	
	memcpy(&buffer[i], &leafnum, sizeof(int));
	i += sizeof(int);

	int pos;

	pos = routing->write_to_buffer(&buffer[i]);
	i += pos;
	//cout << "========= Mtree writing " << i << endl;
	
	
	for (int j = 0; j < leafnum; j++) {
	//	cout <<"======i is "<<i<< " this is son " << j << " ";
	//	son[j]->outnode("try ");
		
		pos = son[j]->write_to_buffer(&buffer[i]);
		i += pos;		

//		cout << "====== Finish son " << j << " leafnum " << leafnum << " ===== check len " << pos << endl;
	}

	//outnode();
	//cout << "total size " << i<<endl;
	//cout << " tst " << getsize()<<endl;
	return i;
}
void Mtree::outnode(string str)
{
	cout<<str<<"Block "<<block <<" isleaf "<<isleaf<< " fa " << fa << " leafnum " << leafnum << endl;	
	routing->outnode(str+ " Routing ");
	for (int i = 0; i < leafnum; i++)son[i]->outnode("    " + str);			
	cout << endl;
}
void Mtree::loadroot(int  page) {
	char*buf=new char[Index_f->file->get_blocklength()];
	if (Index_c == NULL) {
		Index_f->file->read_block(buf, page);
	}
	else {
		//	cout << "read from cache" << endl;
		Index_c->read_block(buf, page, Index_f);
	}
	read_from_buffer(buf);
	block = page;
	delete[] buf;
}
void Mtree::entere(Mnode* q) {
	Mnode** tmp = new Mnode * [leafnum + 1];
	//	cout << "======= Entere" << endl;
	for (int i = 0; i < leafnum; i++) {
		tmp[i] = son[i];
		//		son[i]->outnode("");
		son[i] = NULL;
	}

	delete[] son;
	tmp[leafnum] = q;
	son = tmp;
	leafnum++;
	/*
	for (int i = 0; i < leafnum; i++) {
		cout << "new ";
		son[i]->outnode("");
	}
	*/
	dirty = 1;
}
void Mtree::flush() {
	char* buf;
//	cout << "This Mtree is dirty, rewrite! " << endl;
	//		outnode("Dirty ");
	buf = new char[Index_f->file->get_blocklength()];
	write_to_buffer(buf);
//	cout << "Write fin " << endl;
	dirty = 0;
	if (Index_c == NULL) // no cache
		Index_f->file->write_block(buf, block);
	else
		Index_c->write_block(buf, block, Index_f);
	delete[] buf;
}
void Mtree::insert(Mnode* q) {
//	if (f == 1) {cout << "==============inserting ";outnode("");}
	if (isleaf == 1) {
		entere(q);
		//cout << "Leaf insert" << endl;
		double s = getsize();
		if (s >= Index_f->file->get_blocklength()) {
			if (f == 1) {cout << "==============going split ";outnode("");}
			this->split(0, NULL);
		}
		//cout << "insert fin" << endl;
		//outnode("insert fin");
	}
	else {
//		cout << "None Root insert" << endl;
		double tmp = 0;
		int pos=0;
		int flag = 0;
		double* dis = new double[leafnum];
		for (int i = 0; i < leafnum; i++) {
			dis[i] = son[i]->distance(q);
			if (dis[i] <= son[i]->radi) {
				flag = 1;
				tmp = dis[i];
				pos = i;
			}
		}		
//		cout << "Find finish" << endl;
		if (flag==1) {
//if (f == 1)			cout << "flag=1" << endl;
			for (int i = 0; i < leafnum; i++) 
				if (dis[i] <= son[i]->radi) {
					if (tmp > dis[i]) {
						pos = i;
						tmp = dis[i];
					}
				}
	//		if (f == 1)		cout << "Dis in Radi " << dis[pos] << " "<<son[pos]->radi << endl;
		}
		else {
//if (f==1)			cout << "flag=0" << endl;
			pos = 0;
			tmp = dis[0] - son[0]->radi;
			for (int i = 1; i < leafnum; i++)
				if (dis[i]-son[i]->radi<tmp) {
					tmp = dis[i] - son[i]->radi;
					pos = i;					
				}
			son[pos]->radi = dis[pos];
			
			//if (f == 1)		cout << "Dis and Radi " << dis[pos] << " " << son[pos]->radi << endl;
		}
		flush();
		//this->flush();
		q->fadis = dis[pos];
		delete[] dis;
		Mtree* p = new Mtree();
//		p->outnode("");
		p->loadroot(son[pos]->son);
		p->fa = block;
//		cout << "Load finish" << endl;
		p->insert(q);		
		//cout << "ins " << endl;
		delete p;
//		cout << "ins fin" << endl;
		
	}
}
void Mtree::bfs(string str) {
	
	//outnode(str);
	if (isleaf == 1) return;
	radi = 0;
	for (int i = 0; i < leafnum; i++) {
		radi = max(son[i]->fadis + son[i]->radi, radi);
		
		Mtree* p = new Mtree();
		p->loadroot(son[i]->son);
		if (p->routing->objloc != son[i]->objloc) { cout << "!!!!!!!!!! this is not ok " << endl; p->outnode("son "); outnode("root ");  cout << " ========== " << endl; }
		
		if (p != NULL)p->bfs("  "+ str );
		
		delete p;
	}	
	
}
void Mtree::bfs1(string str) {

	outnode(str);
	if (isleaf == 1) return;	
	for (int i = 0; i < leafnum; i++) {
		Mtree* p = new Mtree();
		p->loadroot(son[i]->son);
		if (p != NULL)p->bfs1(str + "  ");
		delete p;
	}

}
void Mtree::split(int flag, Mtree* rtt) {

	dirty = 1;
	//if (f == 1) {cout << "=========== Splitting !!! ========= " << f << endl;outnode("Splitting ");}

	if (leafnum < 2) cout << "=========== Error Leaf is not enough !!! =========" << endl;
	int* loc = new int[leafnum];
	for (int i = 0; i < leafnum; i++) loc[i] = -1;
	int j = rand() % (leafnum/2);
	int i = rand() % (leafnum / 2) + leafnum / 2;
//	cout << "-0001              insert in root" << endl << endl;
	int leafi = 0, leafj = 0;
	double disri = 0, disrj = 0;
	Mnode* ri = new Mnode();
	ri->copy(son[i]);
	loc[i] = 0;
	Mnode* rj = new Mnode();
	rj->copy(son[j]);
	loc[j] = 1;

//	cout << "beging "<<leafnum << endl;
	for (int i = 0; i < leafnum; i++) {
	//	cout << "i is " << i << endl;

	//	son[i]->outnode("son ");
		double tmpdisi = son[i]->distance(ri);
		double tmpdisj = son[i]->distance(rj);
	//	cout<<"fin " << endl;
		if (tmpdisi > tmpdisj||loc[i]==1) {
			rj->radi = max(rj->radi, tmpdisj + son[i]->radi);
			son[i]->fadis = tmpdisj;
			leafj++;
			loc[i] = 1;
	//		cout << " 1 "<<tmpdisi<<" "<<tmpdisj<<endl;
		}
		else {
			ri->radi = max(ri->radi, tmpdisi + son[i]->radi);
			son[i]->fadis = tmpdisi;
			leafi++;
			loc[i] = 0;
	//		cout << " 0 " << tmpdisi << " " << tmpdisj << endl;
		}
	}
//	cout<<"continue" << endl;
//	if (f == 1) {ri->outnode("ri ");rj->outnode("rj ");}
	
	if (fa == -1) {
//		cout << "              insert in root" << endl << endl;
		Mtree* n1 = new Mtree(); 
		Mtree* n2 = new Mtree();
		n1->fa = block;
		n2->fa = block;
		// ================================ son need to change, together with block
		n1->isleaf = isleaf;
		n2->isleaf = isleaf;
		char* buf = new char[Index_f->file->get_blocklength()];
		n1->write_to_buffer(buf);
		n1->block = Index_f->file->append_block(buf);
		n1->dirty = 1;
		n2->write_to_buffer(buf);
		n2->block = Index_f->file->append_block(buf);
		delete[] buf;
		n2->dirty = 1;
		ri->son = n1->block;
		rj->son = n2->block;
		isleaf = 0;
		n1->son= new Mnode * [leafi];
		n2->son = new Mnode * [leafj];
		n1->leafnum = leafi;
		n2->leafnum = leafj;		
		leafi = 0;
		leafj = 0;
//		outnode("before splut ");
	//	cout << "0001              insert in root" << endl << endl;
//		cout << "n1 + n2 " << leafnum << endl;
		for (int i = 0; i < leafnum; i++) {
			if (loc[i] == 0) {
				n1->son[leafi++] = son[i];
				son[i] = NULL;
			}
			else {
				n2->son[leafj++] = son[i];
				son[i] = NULL;
			}
		}
		//if (leafi != n1->leafnum) cout << "leafnum not equal !!!!" << endl;
		//if (leafj != n2->leafnum) cout << "leafnum not equal !!!!" << endl;
		//if (ri->metric < 0) cout << "============== finded" << endl;
		//if (rj->metric < 0) cout << "============== finded" << endl;
		delete[] son;
//		cout << "0002              insert in root" << endl << endl;
		leafnum = 2;
		son=new Mnode * [2];
		ri->fadis = 0;
		rj->fadis = 0;
		son[0] = ri;
		son[1] = rj;
		Mnode* rii = new Mnode();
		rii->copy(ri);
		Mnode* rjj = new Mnode();	
		rjj->copy(rj);
		n1->routing = rii;
		n2->routing = rjj;
		//n1->outnode("n1 ");
		//n2->outnode("n2 ");
		//outnode("this ");
		//cout << "prep" << endl;
		if (n1->getsize() >= Index_f->file->get_blocklength()) n1->split(1,this);
		//cout << "prep 1" << endl;
		if (n2->getsize() >= Index_f->file->get_blocklength()) n2->split(1,this);
		
		//cout << "prep 4" << endl;
		if (getsize() >= Index_f->file->get_blocklength()) split(0, NULL);		
		delete n1;
		delete n2;
		//outnode("splut fin ");
	}
	else {

		Mtree* rt;
		if (flag == 0) {
			rt = new Mtree();
			rt->loadroot(fa);//	if(f==1)		cout << "              insert in normal node" << endl << endl;
		}
		else {
			rt = rtt;//if (f == 1)		cout << "              double insert in normal node" << endl << endl;
		}
		Mtree* n2 = new Mtree();
		n2->fa = fa;		
		n2->isleaf = isleaf;
		char* buf = new char[Index_f->file->get_blocklength()];
		n2->write_to_buffer(buf);
		n2->block = Index_f->file->append_block(buf);
		delete[] buf;
		ri->son = block;
		rj->son = n2->block;		
	//	if (f == 1) {cout << "n1 block " << block << endl;	cout << "n2 block " << n2->block << endl;}
		Mnode* rii = new Mnode();
		rii->copy(ri);
		Mnode* rjj = new Mnode();
		rjj->copy(rj);
		routing = rii;
		dirty = 1;
		rt->dirty = 1;
		n2->routing = rjj;
		n2->dirty = 1;
//		cout << "0002             insert in normal node" << endl << endl;
		if (rt->fa == -1) {
			ri->fadis = 0;
			rj->fadis = 0;
		}
		else {
			ri->fadis = ri->distance(rt->routing);
			rj->fadis = rj->distance(rt->routing);
		}

		rt->entere(rj);
		
		//cout << "0003              insert in normal node" << endl << endl;
		for (int i = 0; i < rt->leafnum; i++) if(rt->son[i]->son==block){
			rt->son[i] = ri;
			break;
		}		
//		rt->outnode("!!!!first rt ");
		Mnode** tmp = son;
		son=new Mnode* [leafi];
		n2->son = new Mnode * [leafj];		
		n2->leafnum = leafj;
		leafi = 0;
		leafj = 0;
		//cout << "0005              insert in normal node" << endl << endl;
//		cout << " 002             insert in normal node" << endl << endl;
		for (int i = 0; i < leafnum; i++) {
			if (loc[i] == 0) {
				son[leafi++] = tmp[i];
				tmp[i] = NULL;
			}
			else {
				n2->son[leafj++] = tmp[i];
				tmp[i] = NULL;
			}
		}
		delete[] tmp;
		leafnum = leafi;
//		cout << " 003             insert in normal node leafnum " << leafnum << " leafi & j " << leafi<< " "<<leafj << endl << endl;
		n2->fa = rt->block;
		fa = rt->block;

		if (getsize() >= Index_f->file->get_blocklength())	split(1, rt);
		if (n2->getsize() >= Index_f->file->get_blocklength()) n2->split(1, rt);
		
		if (flag==0&&rt->getsize() >= Index_f->file->get_blocklength()) rt->split(0,NULL);

		//cout << "prep 2 4" << endl;
		//if (f == 1) {	cout << "split finish " << endl;rt->outnode(" split root ");}

		if (flag == 0) delete rt;		
		delete n2;		
	}	
	delete[]loc;
	//if (f == 1) cout << "========= Finish Splitting" << endl;
}

void Mtree::updaterad(int loc,double sradi) {
//	cout << "============== upradi " << loc << endl;
	double or = radi;
	radi = 0;
	for (int i = 0; i < leafnum; i++){
		if (son[i]->son==loc)	son[i]->radi = sradi;	
		radi = max(radi, son[i]->fadis + son[i]->radi);
	}
	if (or==radi||fa<=0) return;
	Mtree* p = new Mtree();
	p->loadroot(fa);
	p->updaterad(block, radi);
	p->dirty = 1;
	delete p;
}

void Mtree::delnode(int loc) {
//	cout<<"==============deleting "<<loc<<endl;	
	int pos = -1;
	for (int i = 0; i < leafnum; i++) {
		if(son[i]->son==-1){
			if (son[i]->objloc == loc) {
				pos = i;
				break;
			}
		}
		else if (son[i]->son == loc) {
			pos = i;
			break;
		}
	}
	if (pos == -1) {
		cout << "error delnode "<<loc << endl;
		//outnode("======not find ");
		return;
	}
	Mnode** tmp = new Mnode * [leafnum-1];
	for (int i = 0; i < pos; i++) tmp[i] = son[i];
	for (int i = pos + 1; i < leafnum; i++) tmp[i - 1] = son[i];
	for (int i = 0; i < leafnum; i++) son[i] = NULL;
	delete[] son;
	son = tmp;
	leafnum--;

	dirty = 1;
	if (leafnum == 0&&fa>=0) {
		Mtree* p = new Mtree();
		p->loadroot(fa);
		p->delnode(block);
		delete p;
	}
	else {
		radi = 0;
		for (int i = 0; i < leafnum; i++) radi = max(radi, son[i]->fadis + son[i]->radi);
		if (fa == -1) return;
		Mtree* p = new Mtree();
		p->loadroot(fa);
		p->updaterad(block,radi);
		p->dirty = 1;
		delete p;
	}
}

vector<AnsLeaf*> Mtree::rangeq(int root, Mnode* q, double r, int flag) {
	vector<AnsLeaf*> tmp;
	queue<AnsLeaf*> stack;
	AnsLeaf* p = new AnsLeaf(root, q->metric, 0);
	p->loc = -1;
	stack.push(p);
	while (stack.size() > 0) {
		AnsLeaf* pos = stack.front();
		stack.pop();
		Mtree* rt = new Mtree();
		rt->loadroot(pos->obj);
		if (flag == 1 && rt->fa != pos->loc) {
			rt->fa = pos->loc;
			rt->dirty = 1;
		}
		//rt->outnode("Range single test ");
		//cout << "Obj " << pos->obj << endl;
		for (int i = 0; i < rt->leafnum; i++) {

			if (rt->isleaf == 0) {
				//cout << "dis 2 posdis " << pos->dis<<" son[i]fadis " <<rt->son[i]->fadis <<" r "<< abs(pos->dis - rt->son[i]->fadis) << " r " << r + rt->son[i]->radi << endl;
				if (abs(pos->dis - rt->son[i]->fadis) <= r + rt->son[i]->radi) {
					double dis = rt->son[i]->distance(q);
					//cout << "dis 1 " << dis << " r " << rt->son[i]->radi + r << endl;
					if (dis <= rt->son[i]->radi + r) {
						AnsLeaf* qq = new AnsLeaf(rt->son[i]->son, q->metric, dis);
						qq->loc = pos->obj;
						stack.push(qq);
					}
					//else cout << "pruned" << endl;
					
				}
				//else cout << "pruned" << endl;
				
			}
			else {
				//cout << "dis 4 " << abs(pos->dis - rt->son[i]->fadis) << " r " << r << endl;
				if (abs(pos->dis - rt->son[i]->fadis) <= r) {
					double dis = rt->son[i]->distance(q);
					//cout << "dis 3 " << dis << " r " << r<<endl;
					if (dis <= r) {
						AnsLeaf* qq = new AnsLeaf(rt->son[i]->objloc, q->metric, dis);
						qq->loc = pos->obj;
						//	if (flag == 1) {cout << "Pushing " << rt->son[i]->objloc << " - " << dis << " - " << r << endl;rt->outnode("");		}
						tmp.push_back(qq);
					}
					//else cout << "pruned" << endl;
					
				}
				//else cout << "pruned" << endl;
				
			}
		}
		//cout << "searching ";
		//rt->outnode("RNN ");
		delete rt;
		delete pos;
	}
	//for (int i = 0; i < tmp.size(); i++) cout << "objloc " << tmp[i]->obj << endl;
	return tmp;
}

vector<AnsLeaf*> Mtree::knnq(int root, Mnode* q,int knn) {
	vector<AnsLeaf*> tmp;
	vector<AnsLeaf*> tmpres;
	struct cmp {
		bool operator() (AnsLeaf* a, AnsLeaf* b) {			
			double aa = a->dis - a->radi;
			double bb = b->dis - b->radi;
			aa = MAX(aa, 0);
			bb = MAX(bb, 0);
			if ( aa> bb) return 1;
			else return 0;
		}
	};
	struct cmp1 {
		bool operator() (double a, double b) {
			if (a < b) return 1;
			return 0;
		}
	};
	priority_queue<AnsLeaf*, vector<AnsLeaf*>, cmp> candlist;
	priority_queue<double, vector<double>, cmp1> reslist;

	AnsLeaf* p = new AnsLeaf(root, q->metric, 0);
	p->loc = -1;
	p->radi = 0;
	candlist.push(p);

	while (candlist.size() > 0) {
		p = candlist.top();
		candlist.pop();
		double dd = MAX(p->dis - p->radi, 0);
		if (reslist.size()<knn|| dd < reslist.top()) {

			Mtree* rt = new Mtree();
			rt->loadroot(p->obj);
		//	rt->outnode("KNN ");
			for (int i = 0; i < rt->leafnum; i++) {				
				if (rt->isleaf == 1) {
					//cout << " ============ " << reslist.size() << " " << knn << endl;

					if(reslist.size() < knn||abs(p->dis-rt->son[i]->fadis)<=reslist.top()){
					//	cout << "ready 1" << endl;
						double dis = rt->son[i]->distance(q);
						AnsLeaf* qq = new AnsLeaf(rt->son[i]->objloc, q->metric, dis);
						qq->loc = p->obj;
						//	if (flag == 1) 	{cout << "Pushing ";rt->son[i]->outnode("");		}
						tmp.push_back(qq);
						reslist.push(dis);
						while (reslist.size() > knn) reslist.pop();
					}
				}
				else {
					//cout<<" ============ " << reslist.size()<<" "<<knn << endl;
					if (reslist.size() < knn || abs(p->dis - rt->son[i]->fadis) <= reslist.top()+rt->son[i]->radi) {
//						cout << "ready 2" << endl;
						double dis = rt->son[i]->distance(q);
						AnsLeaf* qq = new AnsLeaf(rt->son[i]->son, q->metric, dis);
						qq->radi = rt->son[i]->radi;
						qq->loc = p->obj;
						candlist.push(qq);						
					}
				}
			}
			delete rt;
		}
		delete p;		
	}
	if (reslist.size() < knn) return tmp;
	double dis = reslist.top();
	//	cout << "existing "<< tmp.size()<<endl;

	for (int i = 0; i < tmp.size(); i++) {
		p = tmp[i];
		//cout << "existing ";
		//p->outnode();
		if (p->dis <= dis) {
			tmpres.push_back(p);
		}
		else {
			delete p;
		}
		tmp[i] = NULL;
	}
	tmp.clear();
	return tmpres;
}



