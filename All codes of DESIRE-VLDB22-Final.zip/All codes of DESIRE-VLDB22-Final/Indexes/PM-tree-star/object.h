#ifndef MIN
#define MIN(x, y) ((x<y)? (x): (y))
#define MAX(x, y) ((x>y)? (x): (y))
#endif

#ifndef __Object
#define __Object
#ifndef __leafmax
#define __leafmax

#define PIVOTN 0.6
#define LEAFMAX 5
#define LEAFMAXM 5

#endif



#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <iostream>
#include <sstream>
#include <time.h>
#include <cmath>
#include "basemetric.h"
#include "./iopack/RAF.h"
using namespace std;


extern int n, m;
extern int f;
extern int* metricm;
extern double* metricmaxdis;
extern double compdists;
class Object
{
public:
	//data
	int id;		
	int sized, sizes;
	int* size;
	double* datad;
	char* datas;

	//tmpsize
	int istravel;
	double* ansres;
	double dist;           

	
	void ini(string str);
	void outnode();
	Object();	
	Object(Object* o);
	~Object();
	int write_to_buffer(char* buffer);
	int read_from_buffer(char* buffer);
	int getsize();

	double distance(Object* other, int m) ;

//	bool operator < (const Object& a) const;
//	bool operator > (const Object& a) const;
};

class Objectarr
{
public:
	Object** arr;	
	Objectarr();
	~Objectarr();
	
	void readfile(string filedata);	
};


#endif

